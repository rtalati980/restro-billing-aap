const config = {
  API_URL: "http://localhost:5000/api", // your backend base URL
};

export default config;
