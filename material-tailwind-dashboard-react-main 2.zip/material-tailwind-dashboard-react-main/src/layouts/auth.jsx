// src/layouts/auth.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import routes from "@/routes";

export function Auth() {
  return (
    <div className="relative min-h-screen w-full">
      <Routes>
        {routes
          .filter((r) => r.layout === "auth")
          .flatMap((r) => r.pages)
          .map(({ path, element }, index) => (
            <Route key={index} path={path} element={element} />
          ))}

        <Route path="*" element={<Navigate to="sign-in" replace />} />
      </Routes>
    </div>
  );
}

export default Auth;
