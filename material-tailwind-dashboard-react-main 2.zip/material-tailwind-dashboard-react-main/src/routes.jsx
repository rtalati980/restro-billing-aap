import {
  HomeIcon,
  UserCircleIcon,
  TableCellsIcon,
  InformationCircleIcon,
  Square3Stack3DIcon,
  QueueListIcon,
  ServerStackIcon,
  WindowIcon,
  Cog6ToothIcon,
} from "@heroicons/react/24/solid";

import {
  Home,
  Profile,
  Tables,
  Menu,
  Order,
  Category,
  OrderHistory,
  Settings,
  Notifications,
} from "@/pages/dashboard";

import { SignIn, SignUp } from "@/pages/auth";

const icon = { className: "w-5 h-5 text-inherit" };

export const routes = [
  {
    layout: "dashboard",
    pages: [
      { icon: <HomeIcon {...icon} />, name: "dashboard", path: "home", element: <Home /> },
      { icon: <UserCircleIcon {...icon} />, name: "profile", path: "profile", element: <Profile /> },
      { icon: <TableCellsIcon {...icon} />, name: "tables", path: "tables", element: <Tables /> },
      { icon: <Square3Stack3DIcon {...icon} />, name: "category", path: "category", element: <Category /> },
      { icon: <QueueListIcon {...icon} />, name: "menu", path: "menu", element: <Menu /> },
      { icon: <ServerStackIcon {...icon} />, name: "order", path: "order", element: <Order /> },
      { icon: <WindowIcon {...icon} />, name: "orderHistory", path: "orderhistory", element: <OrderHistory /> },
      { icon: <Cog6ToothIcon {...icon} />, name: "setting", path: "setting", element: <Settings /> },
      { icon: <InformationCircleIcon {...icon} />, name: "notifications", path: "notifications", element: <Notifications /> },
    ],
  },
  {
    layout: "auth",
    pages: [
      { path: "sign-in", element: <SignIn /> },
      { path: "sign-up", element: <SignUp /> },
    ],
  },
];

export default routes;
