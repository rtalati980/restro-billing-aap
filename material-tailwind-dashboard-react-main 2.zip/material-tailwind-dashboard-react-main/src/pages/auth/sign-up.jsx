import React, { useState } from "react";

const Typography = ({ variant, children, className, color }) => (
  <div
    className={`font-sans ${className} ${
      variant === "h2"
        ? "text-2xl font-bold"
        : variant === "paragraph"
        ? "text-base"
        : "text-sm font-medium"
    } text-${color || "gray-900"}`}
  >
    {children}
  </div>
);

const Input = ({ size, placeholder, className, value, onChange, required, type = "text" }) => (
  <input
    type={type}
    className={`w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 focus:border-gray-900 ${className} ${
      size === "lg" ? "text-lg" : "text-base"
    }`}
    placeholder={placeholder}
    value={value}
    onChange={onChange}
    required={required}
  />
);

const Button = ({ fullWidth, className, type, children }) => (
  <button
    type={type}
    className={`bg-gray-900 text-white p-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors ${className} ${
      fullWidth ? "w-full" : ""
    }`}
  >
    {children}
  </button>
);

const API_BASE_URL = "http://localhost:5000/api/auth";

export function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [message, setMessage] = useState(null); // success/error message

  // 🔹 Generate restro_id automatically
  const generateRestroId = () => {
    const uniquePart = Math.floor(1000 + Math.random() * 9000); // random 4-digit number
    return `RESTRO-${uniquePart}`;
  };

  const handleEmailSignUp = async (e) => {
    e.preventDefault();

    const restro_id = generateRestroId();

    try {
      const response = await fetch(`${API_BASE_URL}/signup/email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, restro_id }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({ type: "success", text: "🎉 Sign Up Successful! Please log in." });
        setName("");
        setEmail("");
        setPassword("");
      } else {
        setMessage({ type: "error", text: data.message || "Sign Up Failed." });
      }
    } catch (error) {
      console.error("Network Error:", error);
      setMessage({ type: "error", text: "Network error occurred during signup." });
    }
  };

  return (
    <section className="m-8 flex flex-col lg:flex-row gap-8 min-h-screen items-center">
      <div className="w-full lg:w-3/5 mt-8 lg:mt-0">
        <div className="text-center">
          <Typography variant="h2" className="font-bold mb-4 text-gray-900">
            Sign Up
          </Typography>
          <Typography
            variant="paragraph"
            color="blue-gray"
            className="text-lg font-normal text-gray-600"
          >
            Create your account with email and password.
          </Typography>
        </div>

        <div className="mt-8 mb-2 mx-auto w-full max-w-lg">
          <form className="mt-8 mb-2 mx-auto w-full" onSubmit={handleEmailSignUp}>
            <div className="mb-1 flex flex-col gap-6">
              <Typography variant="small" className="-mb-3 font-medium">
                Name
              </Typography>
              <Input
                size="lg"
                placeholder="Your Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />

              <Typography variant="small" className="-mb-3 font-medium mt-4">
                Email
              </Typography>
              <Input
                size="lg"
                placeholder="name@mail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

              <Typography variant="small" className="-mb-3 font-medium mt-4">
                Password
              </Typography>
              <Input
                type="password"
                size="lg"
                placeholder="********"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button className="mt-6" fullWidth type="submit">
              Sign Up
            </Button>

            {message && (
              <div
                className={`mt-4 p-3 rounded-lg text-center ${
                  message.type === "success"
                    ? "bg-green-100 text-green-800"
                    : "bg-red-100 text-red-800"
                }`}
              >
                {message.text}
              </div>
            )}
          </form>

          <Typography
            variant="paragraph"
            className="text-center text-gray-500 font-medium mt-6 text-sm"
          >
            Already have an account?
            <a
              href="/auth/sign-in"
              className="text-gray-900 ml-1 font-semibold hover:underline"
            >
              Sign In
            </a>
          </Typography>
        </div>
      </div>

      <div className="w-full lg:w-2/5 h-96 lg:h-[80vh] hidden lg:block rounded-3xl overflow-hidden shadow-xl">
        <img
          src="https://placehold.co/800x1200/4B5563/FFFFFF?text=Restaurant+Management"
          alt="Abstract pattern representing management"
          className="h-full w-full object-cover"
        />
      </div>
    </section>
  );
}

export default SignUp;
