import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

// ---- Dummy Replacements for Material Tailwind Components ----

const Typography = ({ variant, children, className }) => (
    <div className={`${variant === 'h2' ? 'text-3xl font-bold' : 'text-sm font-medium'} ${className}`}>
        {children}
    </div>
);

const Input = ({ type = "text", placeholder, value, onChange, disabled }) => (
    <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
        className={`w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 ${
            disabled ? "bg-gray-100 cursor-not-allowed" : ""
        }`}
    />
);

const Button = ({ children, onClick, type = "button", fullWidth = false }) => (
    <button
        type={type}
        onClick={onClick}
        className={`bg-gray-900 text-white p-3 rounded-lg hover:bg-gray-800 transition w-full`}
    >
        {children}
    </button>
);

const Tab = ({ active, label, onClick }) => (
    <button
        onClick={onClick}
        className={`flex-1 text-center py-3 rounded-lg ${
            active ? "bg-gray-800 text-white" : "bg-gray-200 text-gray-700"
        }`}
    >
        {label}
    </button>
);

// -------------------

const API_BASE_URL = "http://localhost:5000/api/auth";

export function SignIn() {
    const navigate = useNavigate();

    const [activeTab, setActiveTab] = useState("email");

    // Email login
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    // Mobile login
    const [mobile, setMobile] = useState("");
    const [otp, setOtp] = useState("");
    const [otpRequested, setOtpRequested] = useState(false);

    // ---------------- EMAIL LOGIN ----------------
    const handleEmailSignIn = async (e) => {
        e.preventDefault();

        try {
            const res = await fetch(`${API_BASE_URL}/signin/email`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password }),
            });

            const data = await res.json();

            if (res.ok) {
                toast.success("Login successful!");
                localStorage.setItem("token", data.token);
                navigate("/dashboard/home");
            } else {
                toast.error(data.message);
            }
        } catch (err) {
            toast.error("Something went wrong!");
        }
    };

    // ---------------- OTP REQUEST ----------------
    const handleRequestOtp = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/signin/mobile/request-otp`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ mobile }),
            });

            const data = await res.json();

            if (res.ok) {
                toast.success("OTP sent successfully!");
                setOtpRequested(true);
            } else {
                toast.error(data.message);
            }
        } catch (err) {
            toast.error("Something went wrong!");
        }
    };

    // ---------------- OTP VERIFY ----------------
    const handleVerifyOtp = async (e) => {
        e.preventDefault();

        try {
            const res = await fetch(`${API_BASE_URL}/signin/mobile/verify-otp`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ mobile, otp }),
            });

            const data = await res.json();

            if (res.ok) {
                toast.success("Logged in!");
                localStorage.setItem("token", data.token);
                navigate("/dashboard/home");
            } else {
                toast.error(data.message);
            }
        } catch (err) {
            toast.error("Something went wrong!");
        }
    };

    // ---------------- FORMS ----------------

    const EmailForm = (
        <form onSubmit={handleEmailSignIn}>
            <div className="mt-4">
                <Typography variant="small">Email</Typography>
                <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" />
            </div>

            <div className="mt-4">
                <Typography variant="small">Password</Typography>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="********" />
            </div>

            <Button type="submit" fullWidth className="mt-6">
                Sign In
            </Button>
        </form>
    );

    const MobileForm = (
        <form onSubmit={handleVerifyOtp}>
            <div className="mt-4">
                <Typography>Mobile Number</Typography>
                <Input
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="9876543210"
                    disabled={otpRequested}
                />
            </div>

            {otpRequested && (
                <div className="mt-4">
                    <Typography>OTP</Typography>
                    <Input value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="1234" />
                </div>
            )}

            {!otpRequested ? (
                <Button fullWidth className="mt-6" onClick={handleRequestOtp}>
                    Send OTP
                </Button>
            ) : (
                <Button type="submit" fullWidth className="mt-6">
                    Verify & Login
                </Button>
            )}
        </form>
    );

    return (
        <section className="min-h-screen flex items-center justify-center p-6">
            <div className="w-full max-w-xl bg-white shadow-lg p-8 rounded-xl">
                <Typography variant="h2" className="text-center mb-4">
                    Sign In
                </Typography>

                {/* Tabs */}
                <div className="flex gap-2 mb-6">
                    <Tab label="Email Login" active={activeTab === "email"} onClick={() => setActiveTab("email")} />
                    <Tab label="Mobile Login" active={activeTab === "mobile"} onClick={() => setActiveTab("mobile")} />
                </div>

                {activeTab === "email" ? EmailForm : MobileForm}

                <p className="text-center mt-6 text-sm text-gray-600">
                    New user?{" "}
                    <a href="/auth/sign-up" className="text-gray-900 font-semibold hover:underline">
                        Create Account
                    </a>
                </p>
            </div>
        </section>
    );
}


export default SignIn;