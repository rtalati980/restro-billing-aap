import { Routes, Route } from "react-router-dom";
import { SignIn, SignUp } from "@/pages/auth";

export function Auth() {
  return (
    <Routes>
      <Route path="sign-in" element={<SignIn />} />
      <Route path="sign-up" element={<SignUp />} />

      {/* optional redirect */}
      <Route path="*" element={<SignIn />} />
    </Routes>
  );
}
