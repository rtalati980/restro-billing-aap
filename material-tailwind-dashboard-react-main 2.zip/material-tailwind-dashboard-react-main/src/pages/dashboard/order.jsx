import React, { useState, useEffect } from "react";

/* ---------------------------------------------------
   CONFIG
--------------------------------------------------- */
const config = {
  API_URL: "http://localhost:5000/api",
};

/* ---------------------------------------------------
   AUTH HEADERS
--------------------------------------------------- */
const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return token
    ? {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      }
    : {};
};

/* ---------------------------------------------------
   ORDER POPUP MODAL
--------------------------------------------------- */
const OrderModal = ({
  open,
  onClose,
  table,
  items,
  menu,
  onAdd,
  onQty,
  onSave,
  onGenerateBill,
}) => {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [remarks, setRemarks] = useState({});
  const [categories, setCategories] = useState([]);

  /** 🔥 FETCH CATEGORY LIST **/
  useEffect(() => {
    if (!open) return;
    const fetchCategories = async () => {
      const res = await fetch(`${config.API_URL}/categories`, {
        headers: getAuthHeaders(),
      });
      setCategories(await res.json());
    };
    fetchCategories();
  }, [open]);

  /** 🧠 FILTER MENU */
  const filteredMenu = menu?.filter(
    (m) =>
      (category === "all" || m.category_id == category) &&
      m.item_name.toLowerCase().includes(search.toLowerCase())
  );

  /** REMARK HANDLER */
  const handleRemarkChange = (id, value) => {
    setRemarks((prev) => ({ ...prev, [id]: value }));
  };

  if (!open || !table) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl p-6 animate-fadeIn">

        {/* HEADER */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-gray-800">
            📋 Order → <span className="text-indigo-600">{table.name}</span>
          </h2>
          <button onClick={onClose} className="text-red-600 text-2xl">
            ✖
          </button>
        </div>

        {/* SEARCH + CATEGORY */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <input
            type="text"
            placeholder="🔍 Search menu"
            className="border p-2 rounded-lg col-span-2"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            className="border p-2 rounded-lg"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">🍽 All Categories</option>
            {categories?.map((c) => (
              <option key={c.id} value={c.id}>
                🟢 {c.name}
              </option>
            ))}
          </select>
        </div>

        {/* MENU LIST */}
        <h3 className="font-semibold text-lg mb-2">📜 Menu</h3>
        <div className="grid grid-cols-3 gap-3 mb-5 max-h-52 overflow-y-auto border rounded p-3">
          {filteredMenu.length ? (
            filteredMenu.map((m) => (
              <div
                key={m.id}
                onClick={() => onAdd(m)}
                className="p-3 rounded border shadow cursor-pointer hover:bg-gray-100"
              >
                <h4 className="font-semibold">{m.item_name}</h4>
                <p className="text-sm text-gray-600">₹{m.price}</p>
              </div>
            ))
          ) : (
            <p className="col-span-3 text-center text-gray-500">
              ❌ No items found
            </p>
          )}
        </div>

        {/* ADDED ITEMS */}
        <h3 className="font-semibold text-lg mb-2">🛒 Added Items</h3>

        {items.length === 0 ? (
          <p className="text-gray-500">No items added yet</p>
        ) : (
          <div className="space-y-3 max-h-52 overflow-y-auto border p-3 rounded">
            {items.map((i) => (
              <div
                key={i.id}
                className="border rounded-lg p-3 flex justify-between items-center shadow-sm"
              >
                <div className="flex-1">
                  <p className="font-bold">{i.item_name}</p>
                  <p className="text-sm text-gray-600">₹{i.price}</p>

                  <input
                    placeholder="✏ Remark"
                    className="border mt-2 px-2 py-1 rounded w-full text-sm"
                    value={remarks[i.id] || ""}
                    onChange={(e) =>
                      handleRemarkChange(i.id, e.target.value)
                    }
                  />
                </div>

                {/* QTY */}
                <div className="flex items-center gap-2 text-lg font-bold">
                  <button
                    onClick={() => onQty(i.id, -1)}
                    className="border px-3 rounded"
                  >
                    -
                  </button>
                  <span>{i.qty}</span>
                  <button
                    onClick={() => onQty(i.id, +1)}
                    className="border px-3 rounded"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ACTION BUTTONS */}
        <div className="flex justify-between mt-6">
          <button
            onClick={onGenerateBill}
            className="bg-purple-600 text-white px-5 py-2 rounded-xl shadow"
          >
            💰 Generate Bill
          </button>

          <button
            onClick={() => onSave(remarks)}
            className="bg-green-600 text-white px-5 py-2 rounded-xl shadow"
          >
            💾 Save Order
          </button>
        </div>
      </div>
    </div>
  );
};

/* ---------------------------------------------------
   MAIN ORDER PAGE
--------------------------------------------------- */
export function Order() {
  const [tables, setTables] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [orders, setOrders] = useState({});

  /** LOAD TABLES **/
  const loadTables = async () => {
    const res = await fetch(`${config.API_URL}/tables`, {
      headers: getAuthHeaders(),
    });
    setTables(await res.json());
  };

  /** LOAD MENU **/
  const loadMenu = async () => {
    const res = await fetch(`${config.API_URL}/menus`, {
      headers: getAuthHeaders(),
    });
    setMenuItems(await res.json());
  };

  useEffect(() => {
    loadTables();
    loadMenu();
  }, []);

  /** OPEN TABLE **/
  const openTableOrder = (table) => {
    setSelectedTable(table);
    setOrders((prev) => ({ ...prev, [table.id]: prev[table.id] || [] }));
    setOrderModalOpen(true);
  };

  /** ADD ITEM **/
  const addItem = (item) => {
    const tId = selectedTable.id;
    const list = orders[tId] || [];
    const ex = list.find((i) => i.id === item.id);

    const updated = ex
      ? list.map((i) =>
          i.id === item.id ? { ...i, qty: i.qty + 1 } : i
        )
      : [...list, { ...item, qty: 1 }];

    setOrders((prev) => ({ ...prev, [tId]: updated }));
  };

  /** UPDATE QTY **/
  const updateQty = (id, diff) => {
    const tId = selectedTable.id;
    const list = orders[tId] || [];

    const updated = list
      .map((i) =>
        i.id === id ? { ...i, qty: Math.max(1, i.qty + diff) } : i
      )
      .filter((i) => i.qty > 0);

    setOrders((prev) => ({ ...prev, [tId]: updated }));
  };

  /** SAVE ORDER **/
  const saveOrder = async (remarks) => {
    const tId = selectedTable.id;

    await fetch(`${config.API_URL}/orders`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({
        table_id: tId,
        items: orders[tId].map((i) => ({
          ...i,
          remark: remarks[i.id] || "",
        })),
      }),
    });

    await fetch(`${config.API_URL}/tables/${tId}/status`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify({ status: false }),
    });

    alert("Order Saved");
    setOrderModalOpen(false);
    loadTables();
  };

  /** GENERATE BILL **/
  const handleGenerateBill = async () => {
    const res = await fetch(
      `${config.API_URL}/orders/${selectedTable.id}/bill`,
      { headers: getAuthHeaders() }
    );

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");

    /** Mark table free */
    await fetch(`${config.API_URL}/orders/${selectedTable.id}/close`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify({ status: true }),
    });

    alert("Bill Generated");
    setOrderModalOpen(false);
    loadTables();
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">🍽 Restaurant Billing</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {tables.map((t) => (
          <div
            key={t.id}
            onClick={() => openTableOrder(t)}
            className={`p-4 rounded-xl shadow cursor-pointer border-2 ${
              t.status
                ? "border-green-500 bg-green-50"
                : "border-red-500 bg-red-50"
            }`}
          >
            <h2 className="font-bold text-lg">{t.name}</h2>
            <p>{t.status ? "Available" : "Occupied"}</p>
          </div>
        ))}
      </div>

      <OrderModal
        open={orderModalOpen}
        onClose={() => setOrderModalOpen(false)}
        table={selectedTable}
        items={orders[selectedTable?.id] || []}
        menu={menuItems}
        onAdd={addItem}
        onQty={updateQty}
        onSave={saveOrder}
        onGenerateBill={handleGenerateBill}
      />
    </div>
  );
}

export default Order;
