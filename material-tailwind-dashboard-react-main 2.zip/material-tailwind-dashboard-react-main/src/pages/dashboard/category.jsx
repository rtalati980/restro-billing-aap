import { useEffect, useState } from "react";

const config = {
  API_URL: "http://localhost:5000/api",
};

const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) return {};

    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };
  };

export function Category() {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState(null);

  const load = async () => {
    const res = await fetch(`${config.API_URL}/categories`, {
      headers: getAuthHeaders(),
    });
    setCategories(await res.json());
  };

  const save = async () => {
    const method = editingId ? "PUT" : "POST";
    const url = editingId
      ? `${config.API_URL}/categories/${editingId}`
      : `${config.API_URL}/categories`;

    await fetch(url, {
      method,
      headers: {
        ...getAuthHeaders(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name }),
    });

    setName("");
    setEditingId(null);
    load();
  };

  const del = async (id) => {
    if (!window.confirm("Delete this category?")) return;

    await fetch(`${config.API_URL}/categories/${id}`, {
      method: "DELETE",
      headers: getAuthHeaders(),
    });

    load();
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold">Categories</h2>

      <div className="flex gap-2 my-2">
        <input
          className="border p-2"
          placeholder="Category Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button className="bg-green-600 text-white px-4" onClick={save}>
          {editingId ? "Update" : "Add"}
        </button>
      </div>

      <table className="w-full border mt-3">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">Name</th>
            <th width="120">Action</th>
          </tr>
        </thead>
        <tbody>
          {categories.map((c) => (
            <tr key={c.id}>
              <td className="border p-2">{c.name}</td>
              <td className="border p-2">
                <button
                  className="text-blue-600"
                  onClick={() => {
                    setEditingId(c.id);
                    setName(c.name);
                  }}
                >
                  Edit
                </button>
                {" | "}
                <button
                  className="text-red-600"
                  onClick={() => del(c.id)}
                >
                  Del
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Category;