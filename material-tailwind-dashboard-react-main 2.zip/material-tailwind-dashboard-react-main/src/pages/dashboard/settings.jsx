import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

const API = "http://localhost:5000/api"; // BACKEND URL

export function Settings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const token = localStorage.getItem("token"); // JWT

  const [editMode, setEditMode] = useState(false); // 👈 NEW

  const [form, setForm] = useState({
    restro_name: "",
    tagline: "",
    address: "",
    gst_number: "",
    sac_code: "",
    tax_percent: "",
    language: "English",
    currency: "₹",
    service_charge: "",
    packing_charge: "",
  });

  /** 🔹 FETCH SETTINGS */
  useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetch(`${API}/settings`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) throw new Error();

        const data = await res.json();
        setForm(data ?? {});
      } catch (e) {
        toast.error("❌ Failed to load settings");
      } finally {
        setLoading(false);
      }
    }

    loadSettings();
  }, []);

  /** 🔹 HANDLE INPUT */
  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  /** 🔹 SAVE SETTINGS */
  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${API}/settings`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(form),
      });

      if (!res.ok) throw new Error();

      toast.success("✅ Settings Saved Successfully");
      setEditMode(false); // 👈 LOCK AGAIN
    } catch (err) {
      toast.error("❌ Failed to update");
    }
    setSaving(false);
  };

  if (loading) return <p className="text-center mt-10">Loading…</p>;

  return (
    <div className="max-w-3xl mx-auto bg-white shadow-xl rounded-xl p-6 mt-6">
      <h1 className="text-2xl font-bold mb-5">Restaurant Settings</h1>

      {/* --- ACTION BUTTON --- */}
      {!editMode ? (
        <button
          onClick={() => setEditMode(true)}
          className="bg-green-600 text-white px-4 py-2 rounded mb-4"
        >
          ✏ Edit Settings
        </button>
      ) : (
        <button
          onClick={handleSave}
          disabled={saving}
          className="bg-blue-600 text-white px-4 py-2 rounded mb-4"
        >
          {saving ? "Saving…" : "💾 Save Settings"}
        </button>
      )}

      <div className="grid grid-cols-2 gap-4">
        <Input readOnly={!editMode} label="Restaurant Name" name="restro_name" value={form.restro_name} onChange={handleChange} />
        <Input readOnly={!editMode} label="Tagline" name="tagline" value={form.tagline} onChange={handleChange} />
        <Input readOnly={!editMode} label="GST Number" name="gst_number" value={form.gst_number} onChange={handleChange} />
        <Input readOnly={!editMode} label="SAC Code" name="sac_code" value={form.sac_code} onChange={handleChange} />
        <Input readOnly={!editMode} label="Tax (%)" name="tax_percent" value={form.tax_percent} onChange={handleChange} />
        <Input readOnly={!editMode} label="Service Charge (%)" name="service_charge" value={form.service_charge} onChange={handleChange} />
        <Input readOnly={!editMode} label="Packing Charge" name="packing_charge" value={form.packing_charge} onChange={handleChange} />

        <Select
          disabled={!editMode}
          label="Language"
          name="language"
          value={form.language}
          options={["English", "Hindi", "Gujarati", "Marathi"]}
          onChange={handleChange}
        />

        <Select
          disabled={!editMode}
          label="Currency"
          name="currency"
          value={form.currency}
          options={["₹", "$", "€"]}
          onChange={handleChange}
        />
      </div>

      <textarea
        readOnly={!editMode}
        name="address"
        value={form.address}
        onChange={handleChange}
        placeholder="Restaurant Address"
        className="border rounded w-full p-3 mt-4"
      />
    </div>
  );
}

/** INPUT COMPONENT */
function Input({ label, name, value, onChange, readOnly }) {
  return (
    <div>
      <label className="text-sm mb-1 block">{label}</label>
      <input
        readOnly={readOnly}
        name={name}
        value={value || ""}
        onChange={onChange}
        className={`border p-2 rounded w-full ${readOnly ? "bg-gray-100" : ""}`}
      />
    </div>
  );
}

/** SELECT COMPONENT */
function Select({ label, name, value, options, onChange, disabled }) {
  return (
    <div>
      <label className="text-sm mb-1 block">{label}</label>
      <select
        disabled={disabled}
        name={name}
        value={value}
        onChange={onChange}
        className={`border p-2 rounded w-full ${disabled ? "bg-gray-100" : ""}`}
      >
        {options.map((op) => (
          <option key={op}>{op}</option>
        ))}
      </select>
    </div>
  );
}

export default Settings;
