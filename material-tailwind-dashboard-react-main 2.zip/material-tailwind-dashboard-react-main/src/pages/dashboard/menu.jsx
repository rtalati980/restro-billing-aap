import React, { useState, useEffect } from "react";

const config = {
  API_URL: "http://localhost:5000/api",
};

const CustomModal = ({ message, type, onConfirm, onCancel }) => {
  if (!message) return null;

  const isConfirm = type === "confirm";
  const bgColor = isConfirm ? "bg-red-500" : "bg-blue-500";
  const title = isConfirm ? "Confirmation" : "Notification";

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl shadow-2xl w-80 max-w-full">
        <h3 className={`text-lg font-bold mb-4 ${bgColor.replace("bg-", "text-")}`}>{title}</h3>
        <p className="text-gray-700 mb-6">{message}</p>

        <div className="flex justify-end space-x-3">
          {isConfirm && (
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300"
            >
              Cancel
            </button>
          )}

          <button
            onClick={onConfirm}
            className={`px-4 py-2 text-sm font-medium text-white ${bgColor} rounded-lg hover:${bgColor.replace(
              "500",
              "600"
            )}`}
          >
            {isConfirm ? "Confirm" : "Close"}
          </button>
        </div>
      </div>
    </div>
  );
};

export function Menu() {
  const [item_name, setitem_name] = useState("");
  const [price, setPrice] = useState("");
  const [category_id, setCategory_id] = useState("");
  const [availability, setAvailability] = useState(true);
  const [menuList, setMenuList] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);

  const [filterCategory, setFilterCategory] = useState(""); // ⭐ NEW

  const [modalState, setModalState] = useState({
    message: null,
    type: "alert",
    onConfirm: () => setModalState({ message: null }),
  });

  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) return {};

    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };
  };

  useEffect(() => {
    loadCategories();
    fetchMenus();
  }, []);

  // ⭐ FETCH CATEGORIES
  const loadCategories = async () => {
    try {
      const res = await fetch(`${config.API_URL}/categories`, {
        headers: getAuthHeaders(),
      });

      const data = await res.json();
      setCategories(data);
    } catch (err) {
      console.error("Failed to load categories", err);
    }
  };

  // ⭐ FETCH MENUS
  const fetchMenus = async () => {
    setLoading(true);

    try {
      const res = await fetch(`${config.API_URL}/menus`, {
        headers: getAuthHeaders(),
      });

      const data = await res.json();
      setMenuList(data);
    } catch (err) {
      console.error("Menu Fetch Failed");
    }

    setLoading(false);
  };

  // ⭐ SAVE MENU
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!item_name || !price || !category_id) {
      return setModalState({ message: "Fill all fields", type: "alert" });
    }

    const menuData = {
      item_name,
      price: Number(price),
      category_id,           // FIXED 🔥 now correct key
      available: availability,
    };

    const method = editingId ? "PUT" : "POST";
    const url = editingId
      ? `${config.API_URL}/menus/${editingId}`
      : `${config.API_URL}/menus`;

    const res = await fetch(url, {
      method,
      headers: getAuthHeaders(),
      body: JSON.stringify(menuData),
    });

    const data = await res.json();

    if (res.ok) {
      setModalState({
        message: editingId ? "Updated successfully" : "Added successfully",
        type: "alert",
      });

      resetForm();
      fetchMenus();
    } else {
      setModalState({ message: data.message || "Failed", type: "alert" });
    }
  };

  // ⭐ RESET FORM
  const resetForm = () => {
    setEditingId(null);
    setitem_name("");
    setPrice("");
    setCategory_id("");
    setAvailability(true);
  };

  // ⭐ EDIT MENU
  const handleEdit = (menu) => {
    setEditingId(menu.id);
    setitem_name(menu.item_name);
    setPrice(menu.price);
    setCategory_id(menu.category_id);
    setAvailability(menu.available);
  };

// ⭐ DELETE CONFIRM POPUP
const handleDeleteConfirm = (id, name) => {
  setModalState({
    message: `Delete '${id}' ,'${name}'?`,
    type: "confirm",
    onConfirm: () => handleDelete(id),
    onCancel: () => setModalState({ message: null, type: "alert" }),
  });
};

// ⭐ DELETE MENU API CALL
const handleDelete = async (id) => {
  // CLOSE CONFIRM POPUP IMMEDIATELY
  setModalState({ message: null, type: "alert" });

  const headers = getAuthHeaders();
  if (!headers.Authorization) return;

  try {
    const res = await fetch(`${config.API_URL}/menus/${id}`, {
      method: "DELETE",
      headers,
    });

    if (res.ok) {
      setModalState({
        message: "Item deleted successfully.",
        type: "alert",
        onConfirm: () => setModalState({ message: null, type: "alert" }),
      });

      fetchMenus();  // 🔥 FIXED
    } else {
      const data = await res.json();
      setModalState({
        message: `Delete failed: ${data.message || "Server error."}`,
        type: "alert",
        onConfirm: () => setModalState({ message: null, type: "alert" }),
      });
    }
  } catch (err) {
    console.error("Error deleting:", err);
    setModalState({
      message: "Network error while deleting.",
      type: "alert",
      onConfirm: () => setModalState({ message: null, type: "alert" }),
    });
  }
};


  // ⭐ FILTERED MENU LIST
  const filteredMenus =
    filterCategory === ""
      ? menuList
      : menuList.filter((m) => m.category_id == filterCategory);

  return (
    <div className="p-4 md:p-8 bg-gray-50 min-h-screen">
      <CustomModal
        message={modalState.message}
        type={modalState.type}
        onConfirm={() => setModalState({ message: null, type: "alert" })}
        onCancel={() => setModalState({ message: null, type: "alert" })}
      />


      <div className="max-w-5xl mx-auto bg-white shadow-2xl rounded-xl">
        <div className="bg-gray-800 p-6 rounded-t-xl">
          <h2 className="text-2xl font-extrabold text-white">
            🍛 Restaurant Menu Management
          </h2>
        </div>

        <div className="p-6">

          {/* ⭐ FILTER DROPDOWN */}
          <select
            className="p-2 border rounded mb-4"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            <option value="">🍽 Show All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* FORM */}
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 sm:grid-cols-5 gap-4 mb-6 p-4 border-2 border-yellow-100 rounded-lg bg-yellow-50"
          >
            <input
              type="text"
              value={item_name}
              onChange={(e) => setitem_name(e.target.value)}
              placeholder="Dish name"
              className="p-3 border rounded"
              required
            />

            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Price ₹"
              className="p-3 border rounded"
              required
            />

            {/* CATEGORY SELECT FIXED */}
            <select
              className="p-3 border rounded"
              value={category_id}
              onChange={(e) => setCategory_id(e.target.value)}
            >
              <option value="">Select Category</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>

            <select
              value={availability}
              onChange={(e) => setAvailability(e.target.value === "true")}
              className="p-3 border rounded"
            >
              <option value="true">Available</option>
              <option value="false">Unavailable</option>
            </select>

            <button className="bg-yellow-600 text-white rounded p-2">
              {editingId ? "Save Changes" : "Add Dish"}
            </button>
          </form>

          {/* TABLE */}
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-200">
                <th className="p-3">Name</th>
                <th className="p-3">Price</th>
                <th className="p-3">Category</th>
                <th className="p-3">Availability</th>
                <th className="p-3">Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredMenus.map((menu) => (
                <tr key={menu.id} className="border">
                  <td className="p-3">{menu.item_name}</td>
                  <td className="p-3">₹{menu.price}</td>

                  {/* ⭐ SHOW CATEGORY NAME */}
                  <td className="p-3">
                    {categories.find((c) => c.id == menu.category_id)?.name ??
                      "--"}
                  </td>

                  <td className="p-3">
                    {menu.available ? "✔" : "❌"}
                  </td>

                  <td className="p-3">
                    <button onClick={() => handleEdit(menu)} className="text-blue-600 mr-3">
                      Edit
                    </button>
                    <button
                      onClick={() =>
                        handleDeleteConfirm(menu.id, menu.item_name)
                      }
                      className="text-red-600"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}

              {filteredMenus.length === 0 && (
                <tr>
                  <td colSpan="5" className="text-center p-4 text-gray-500">
                    No Menu Found
                  </td>
                </tr>
              )}
            </tbody>
          </table>

        </div>
      </div>
    </div>
  );
}

export default Menu;
