import React, { useEffect, useState } from "react";

const config = { API_URL: "http://localhost:5000/api" };

export function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [revenue, setRevenue] = useState(0);

  const getHeaders = () => ({
    Authorization: `Bearer ${localStorage.getItem("token")}`,
  });

  const fetchOrders = async () => {
    let url = `${config.API_URL}/orders/history?`;

    if (from && to) url += `from=${from}&to=${to}&`;
    if (month && year) url += `month=${month}&year=${year}&`;

    const res = await fetch(url, { headers: getHeaders() });
    const data = await res.json();
    setOrders(data.orders || []);

    const totalRevenue = (data.orders || []).reduce(
      (sum, row) => sum + Number(row.total_amount || 0),
      0
    );
    setRevenue(totalRevenue);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <div className="p-6 w-full min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">
        📊 Order History & Revenue
      </h1>

      {/* FILTER SECTION */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-white p-4 rounded-xl shadow-lg">

        <input
          type="date"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
          className="border p-2 rounded"
        />

        <input
          type="date"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          className="border p-2 rounded"
        />

        <select className="border p-2 rounded" value={month} onChange={(e) => setMonth(e.target.value)}>
          <option value="">Month</option>
          {[...Array(12)].map((_, i) => (
            <option key={i+1} value={i + 1}>{i + 1}</option>
          ))}
        </select>

        <select className="border p-2 rounded" value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">Year</option>
          {[2023, 2024, 2025].map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>

        <button
          onClick={fetchOrders}
          className="col-span-1 md:col-span-4 bg-yellow-600 text-white py-2 rounded-lg hover:bg-yellow-700"
        >
          🔍 Filter Orders
        </button>
      </div>

      {/* SUMMARY */}
      <div className="mt-6 p-6 rounded-xl bg-white shadow-xl">
        <h2 className="text-xl font-bold text-gray-700">
          Total Orders : <span className="text-blue-600">{orders.length}</span>
        </h2>

        <h2 className="text-xl font-bold text-gray-700 mt-2">
          Total Revenue : <span className="text-green-600">₹ {revenue}</span>
        </h2>
      </div>

      {/* TABLE */}
      <div className="mt-6 rounded-xl shadow-xl overflow-auto bg-white">
        <table className="min-w-full table-auto">
          <thead className="bg-gray-800 text-white">
            <tr>
              <th className="p-3 text-left">Order ID</th>
              <th className="p-3 text-left">Table</th>
              <th className="p-3 text-left">Amount</th>
              <th className="p-3 text-left">Date</th>
            </tr>
          </thead>

          <tbody>
            {orders.length === 0 ? (
              <tr>
                <td colSpan="4" className="p-4 text-center text-gray-500">
                  No orders found
                </td>
              </tr>
            ) : (
              orders.map((o) => (
                <tr key={o.id} className="border-b hover:bg-gray-50">
                  <td className="p-3 font-mono">{o.id}</td>
                  <td className="p-3">Table {o.table_id}</td>
                  <td className="p-3 font-bold text-green-700">
                    ₹ {o.total_amount}
                  </td>
                  <td className="p-3">
                    {new Date(o.created_at).toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default OrderHistory;
