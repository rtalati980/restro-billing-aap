import React, { useState, useEffect } from "react";

// In a single-file environment, we define a mock config object
const config = {
  API_URL: "http://localhost:5000/api", // Assume API root
};

// Custom Modal component to replace window.confirm and alert
const CustomModal = ({ message, type, onConfirm, onCancel }) => {
  if (!message) return null;

  const isConfirm = type === "confirm";
  const bgColor = isConfirm ? "bg-red-500" : "bg-blue-500";
  const title = isConfirm ? "Confirmation" : "Notification";

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl shadow-2xl w-80 max-w-full transform transition-transform duration-300 scale-100">
        <h3 className={`text-lg font-bold mb-4 ${bgColor.replace('bg-', 'text-')}`}>{title}</h3>
        <p className="text-gray-700 mb-6">{message}</p>
        <div className="flex justify-end space-x-3">
          {isConfirm && (
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition"
            >
              Cancel
            </button>
          )}
          <button
            onClick={isConfirm ? onConfirm : onCancel}
            className={`px-4 py-2 text-sm font-medium text-white ${bgColor} rounded-lg hover:${bgColor.replace('500', '600')} transition`}
          >
            {isConfirm ? "Confirm" : "Close"}
          </button>
        </div>
      </div>
    </div>
  );
};

export function Tables() {
  // --- UPDATED STATE FIELDS ---
  const [name, setName] = useState("");
  const [size, setSize] = useState(""); // Replaced capacity
  const [floor, setFloor] = useState(""); // Added floor/section
  // ----------------------------

  const [tableList, setTableList] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(false);

  // State for Modal Management
  const [modalState, setModalState] = useState({
    message: null,
    type: 'alert', // 'alert' or 'confirm'
    onConfirm: () => {},
    tempDeleteId: null,
  });

  // Helper to get authorization header
  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      console.error("Authentication token not found.");
      return {};
    }
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };
  };

  // ✅ Fetch all tables on component load
  useEffect(() => {
    fetchTables();
  }, []);

  const fetchTables = async () => {
    const headers = getAuthHeaders();
    if (!headers.Authorization) return;
    setLoading(true);

    try {
      // NOTE: In a multi-tenant app, the server should filter by restro_id from the token
      const res = await fetch(`${config.API_URL}/tables`, { headers: { Authorization: headers.Authorization } });

      if (res.status === 401) {
         setModalState({ message: "Session expired or unauthorized. Please log in again.", type: 'alert', onConfirm: () => setModalState({ message: null }) });
         return;
      }

      const data = await res.json();
      setTableList(data);
    } catch (err) {
      console.error("Error fetching tables:", err);
      setModalState({ message: "Failed to fetch tables due to a network error.", type: 'alert', onConfirm: () => setModalState({ message: null }) });
    } finally {
        setLoading(false);
    }
  };

  // ✅ Add or Update table
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !size || !floor) {
      setModalState({ message: "Please fill in all fields (Name, Size, and Floor).", type: 'alert', onConfirm: () => setModalState({ message: null }) });
      return;
    }

    // --- UPDATED DATA STRUCTURE ---
    const tableData = {
      name: name.trim(),
      size: parseInt(size, 10),
      floor: floor.trim(),
      status: true, // Default status: Available
    };
    // ----------------------------

    const headers = getAuthHeaders();
    if (!headers.Authorization) return;

    try {
      if (editingId) {
        // Update existing table
        const res = await fetch(`${config.API_URL}/tables/${editingId}`, {
          method: "PUT",
          headers: headers,
          body: JSON.stringify(tableData),
        });
        const data = await res.json();

        if (res.ok) {
            setModalState({ message: `Table '${data.name}' updated successfully.`, type: 'alert', onConfirm: () => setModalState({ message: null }) });
            setEditingId(null);
        } else {
            setModalState({ message: `Update failed: ${data.message || 'Server error.'}`, type: 'alert', onConfirm: () => setModalState({ message: null }) });
        }
      } else {
        // Add new table
        const res = await fetch(`${config.API_URL}/tables`, {
          method: "POST",
          headers: headers,
          body: JSON.stringify(tableData),
        });
        const data = await res.json();

        if (res.ok) {
            setModalState({ message: `Table '${data.name}' added successfully.`, type: 'alert', onConfirm: () => setModalState({ message: null }) });
        } else {
            setModalState({ message: `Creation failed: ${data.message || 'Server error.'}`, type: 'alert', onConfirm: () => setModalState({ message: null }) });
        }
      }

      // Refresh list and clear form
      fetchTables();
      setName("");
      setSize("");
      setFloor("");
    } catch (err) {
      console.error("Error saving table:", err);
      setModalState({ message: "A network error occurred while saving the table.", type: 'alert', onConfirm: () => setModalState({ message: null }) });
    }
  };

  // ✅ Edit table
  const handleEdit = (table) => {
    // --- UPDATED EDIT HANDLER ---
    setName(table.name.toString());
    setSize(table.size.toString());
    setFloor(table.floor.toString());
    setEditingId(table.id);
    // ----------------------------
  };

  // ✅ Delete table - Step 1: Show confirmation modal
  const handleDeleteConfirm = (id, name) => {
    setModalState({
      message: `Are you sure you want to delete table '${name}'? This action cannot be undone.`,
      type: 'confirm',
      tempDeleteId: id,
      onConfirm: () => handleDelete(id),
      onCancel: () => setModalState({ message: null }),
    });
  };

  // ✅ Delete table - Step 2: Execute deletion
  const handleDelete = async (id) => {
    setModalState({ message: null }); // Close confirmation modal

    const headers = getAuthHeaders();
    if (!headers.Authorization) return;

    try {
      const res = await fetch(`${config.API_URL}/tables/${id}`, {
        method: "DELETE",
        headers: headers,
      });

      if (res.ok) {
        setModalState({ message: "Table deleted successfully.", type: 'alert', onConfirm: () => setModalState({ message: null }) });
        fetchTables();
      } else {
        const data = await res.json();
        setModalState({ message: `Deletion failed: ${data.message || 'Server error.'}`, type: 'alert', onConfirm: () => setModalState({ message: null }) });
      }
    } catch (err) {
      console.error("Error deleting table:", err);
      setModalState({ message: "A network error occurred while deleting the table.", type: 'alert', onConfirm: () => setModalState({ message: null }) });
    }
  };

  // Function to clear editing and form fields
  const handleCancelEdit = () => {
    setEditingId(null);
    setName('');
    setSize('');
    setFloor('');
  }

  // --- Main Render ---
  return (
    <div className="p-4 md:p-8 bg-gray-50 min-h-screen">
      <CustomModal
        message={modalState.message}
        type={modalState.type}
        onConfirm={modalState.onConfirm}
        onCancel={() => setModalState({ message: null })}
      />

      <div className="max-w-5xl mx-auto bg-white shadow-2xl rounded-xl">
        {/* Header */}
        <div className="bg-gray-800 p-6 rounded-t-xl">
          <h2 className="text-2xl font-extrabold text-white">
            <span className="text-green-400">🍽</span> Restaurant Table Management
          </h2>
          <p className="text-gray-300 mt-1">Add, edit, and manage all dining tables (ID is system-generated).</p>
        </div>

        <div className="p-6">
          {/* Form Section */}
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6 p-4 border-2 border-indigo-100 rounded-lg bg-indigo-50"
          >
            {/* Table Name */}
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Table Name (e.g., Table 1, Patio A)"
              className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150"
              required
            />
            {/* Size (Capacity) */}
            <input
              type="number"
              value={size}
              onChange={(e) => setSize(e.target.value)}
              placeholder="Size (Capacity, e.g., 4)"
              className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150"
              required
            />
            {/* Floor/Section */}
            <input
              type="text"
              value={floor}
              onChange={(e) => setFloor(e.target.value)}
              placeholder="Floor/Section (e.g., Main, Balcony)"
              className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150"
              required
            />

            {/* Submit Button */}
            <button
              type="submit"
              className="sm:col-span-1 bg-indigo-600 text-white font-semibold py-3 rounded-lg hover:bg-indigo-700 transition duration-150 shadow-md hover:shadow-lg"
            >
              {editingId ? "Save Changes" : "Add New Table"}
            </button>
          </form>

          {editingId && (
              <button
                onClick={handleCancelEdit}
                className="mb-6 text-sm text-red-600 hover:text-red-800 font-medium transition duration-150"
              >
                  &larr; Cancel Editing Table '{name}'
              </button>
          )}

          {/* Table Display */}
          <h3 className="text-xl font-bold mb-4 text-gray-800">Existing Tables ({tableList.length})</h3>

          {loading ? (
             <div className="text-center py-8 text-blue-500 text-lg font-semibold">Loading tables...</div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-gray-200 shadow-md">
               <table className="min-w-full table-auto border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b border-gray-200">
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider w-20">
                        ID (Snippet)
                      </th>
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider w-24">
                        Size
                      </th>
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Floor/Section
                      </th>
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider w-32">
                        Status
                      </th>
                      <th className="p-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider w-36">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableList.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center text-gray-500 py-6">
                          No tables found for your restaurant. Use the form above to add one!
                        </td>
                      </tr>
                    ) : (
                      tableList.map((table) => (
                        <tr
                          key={table.id}
                          className="even:bg-white odd:bg-gray-50 border-b hover:bg-indigo-50 transition duration-150"
                        >

                          <td className="p-4 text-sm text-gray-800">{table.id}</td>
                          <td className="p-4 text-sm font-bold text-gray-900">{table.name}</td>
                          <td className="p-4 text-sm text-gray-800">{table.size} pax</td>
                          <td className="p-4 text-sm text-gray-800">{table.floor}</td>
                          <td className="p-4 text-sm">
                            <span className={`px-3 py-1 text-xs font-bold rounded-full ${table.status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                {table.status ? 'Available' : 'Occupied'}
                            </span>
                          </td>
                          <td className="p-4 flex gap-3">
                            <button
                              onClick={() => handleEdit(table)}
                              className="text-blue-600 hover:text-blue-800 font-medium transition duration-150 disabled:opacity-50"
                              disabled={!table.status} // Prevent editing occupied tables (logic change)
                              title={!table.status ? "Cannot edit an occupied table" : "Edit"}
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => handleDeleteConfirm(table.id, table.name)}
                              className="text-red-600 hover:text-red-800 font-medium transition duration-150 disabled:opacity-50"
                              disabled={!table.status} // Prevent deleting occupied tables
                              title={!table.status ? "Cannot delete an occupied table" : "Delete"}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
               </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Tables;
