// pages/api/index.js
import pool from "../db/connect";

export default async function handler(req, res) {
  try {
    res.status(200).json({ message: "Database connected successfully" });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Something went wrong" });
  }
}
