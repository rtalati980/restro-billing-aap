const { Pool } = require('pg');
require('dotenv').config( { path: './db/.env'});


const pool = new Pool({
  host: process.env.PG_HOST,
  user: process.env.PG_USER,
  password: process.env.PG_PASSWORD,
  database: process.env.PG_DATABASE,
  port: process.env.PG_PORT,
  // Add SSL configuration here if connecting to a cloud database like Heroku or Render
  // e.g., ssl: { rejectUnauthorized: false }
});

// The index.js file expects an object with a .connect(callback) method.
const database = {
    /**
     * Verifies connectivity to the database by acquiring and releasing a client.
     * @param {function(Error|null): void} callback - The callback function.
     */
    connect: (callback) => {
        pool.connect()
            .then(client => {
                // Connection successful, release the client back to the pool
                client.release();
                callback(null); // Success
            })
            .catch(err => {
                // Failed to connect/acquire client
                callback(err); // Pass the error
            });
    },

    /**
     * Exposes the pool's query method for database operations.
     * @returns {Promise<any> | void}
     */
    query: (text, params, callback) => {
        return pool.query(text, params, callback);
    },

    // You can also expose the raw pool object if needed elsewhere
    pool: pool
};

// Export the module using CommonJS syntax
module.exports = database;
