require('dotenv').config({ path: './db/.env' }); // path to your .env file
const jwt = require('jsonwebtoken');

exports.verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(403).json({ message: 'No authorization header' });

    const token = authHeader.split(' ')[1];
    if (!token) return res.status(403).json({ message: 'No token provided' });

    const JWT_SECRET = process.env.JWT_SECRET; // ✅ get secret from env

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            console.error('Failed to authenticate token:', err.message);
            return res.status(401).json({ message: 'Invalid or expired token' });
        }

        req.userId = decoded.userId;
        req.restroId = decoded.restroId;
// if included in JWT
        next();
    });
};
