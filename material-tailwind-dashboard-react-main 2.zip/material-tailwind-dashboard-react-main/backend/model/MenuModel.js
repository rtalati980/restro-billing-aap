const db = require('../db/connect');
const TABLE_NAME = '"menu"';


/**
 * Creates a new menu item, linking it to a specific restaurant.
 * @param {object} menuData - Item details, including restro_id.
 * @returns {Promise<object>} The created menu item.
 */
async function createMenuItem(menuData) {
  // Ensure we use the quoted TABLE_NAME for consistency with other files
  const query = `
    INSERT INTO ${TABLE_NAME} (category_id, item_name, price, description, restro_id)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *;
  `;

  // ⭐ Added menuData.restro_id for multi-tenancy enforcement
  const values = [
    menuData.category_id,
    menuData.item_name,
    menuData.price,
    menuData.description,
    menuData.restro_id
  ];

  try {
    const result = await db.query(query, values);
    return result.rows[0];
  } catch (error) {
    console.error('Error creating menu item:', error);
    throw error;
  }
}


/**
 * Retrieves all menu items for a specific restaurant.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<Array<object>>} An array of menu items.
 */
async function getAllMenuItems(restroId) {
  // ⭐ Added WHERE clause to filter by restro_id
  const query = `
    SELECT *
    FROM ${TABLE_NAME}
    WHERE restro_id = $1;
  `;
  const result = await db.query(query, [restroId]);
  return result.rows;
}

/**
 * Retrieves menu items under a specific category for a specific restaurant.
 * @param {number} category_id - The category ID.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<Array<object>>} An array of menu items.
 */
async function getMenuByCategory(category_id, restroId) {
  // ⭐ Added AND clause to enforce multi-tenancy
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE category_id = $1 AND restro_id = $2
    ORDER BY id;
  `;
  const result = await db.query(query, [category_id, restroId]);
  return result.rows;
}

/**
 * Updates a menu item for a specific restaurant.
 * @param {number} id - The unique ID of the menu item.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @param {object} updates - The fields to update.
 * @returns {Promise<object|null>} The updated menu item or null if not found.
 */
async function updateMenuItem(id, restroId, { item_name, price, description }) {
  const query = `
    UPDATE ${TABLE_NAME}
    SET item_name = COALESCE($1, item_name),
        price = COALESCE($2, price),
        description = COALESCE($3, description),
        updated_at = NOW()
    WHERE id = $4 AND restro_id = $5
    RETURNING *;
  `;
  // ⭐ Added restroId as the final parameter for the WHERE clause
  const result = await db.query(query, [item_name, price, description, id, restroId]);
  return result.rows[0] || null;
}

/**
 * Deletes a menu item for a specific restaurant.
 * @param {number} id - The unique ID of the menu item.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<number>} The number of rows deleted.
 */
async function deleteMenuItem(id, restroId) {
  // ⭐ Added tenancy filter to the DELETE operation
  const query = `DELETE FROM ${TABLE_NAME} WHERE id = $1 AND restro_id = $2;`;
  const result = await db.query(query, [id, restroId]);
  return result.rowCount;
}

module.exports = {
  createMenuItem,
  getAllMenuItems,
  getMenuByCategory,
  updateMenuItem,
  deleteMenuItem
};
