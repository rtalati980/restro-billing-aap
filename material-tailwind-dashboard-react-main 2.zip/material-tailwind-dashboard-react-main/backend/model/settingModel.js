const db = require('../db/connect');

exports.getSettings = async (restroId) => {
  const result = await db.query(
    `SELECT * FROM settings WHERE restro_id = $1 LIMIT 1`,
    [restroId]
  );
  return result.rows[0];
};


exports.updateSettings = async (restroId, data) => {
  const query = `
    UPDATE settings SET
      restro_name=$1,
      tagline=$2,
      address=$3,
      gst_number=$4,
      sac_code=$5,
      tax_percent=$6,
      language=$7,
      currency=$8,
      service_charge=$9,
      packing_charge=$10,
      updated_at=NOW()
    WHERE restro_id=$11
    RETURNING *;
  `;

  const params = [
    data.restro_name,
    data.tagline,
    data.address,
    data.gst_number,
    data.sac_code,
    data.tax_percent,
    data.language,
    data.currency,
    data.service_charge,
    data.packing_charge,
    restroId
  ];

  const result = await db.query(query, params);
  return result.rows[0];
};
