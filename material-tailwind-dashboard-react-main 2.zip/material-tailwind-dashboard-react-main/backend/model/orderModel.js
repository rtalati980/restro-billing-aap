const db = require('../db/connect');
const TABLE_NAME = 'orders';

/**
 * Creates a new order for a specific restaurant.
 */
async function createOrder({ table_id, items, total_amount, restro_id }) {
  // Prevent null items from crashing the DB
  const safeItems = Array.isArray(items) ? items : [];

  const query = `
    INSERT INTO ${TABLE_NAME} (table_id, items, total_amount, restro_id)
    VALUES ($1, $2, $3, $4)
    RETURNING *;
  `;

  const values = [
    table_id,
    JSON.stringify(safeItems),   // Always JSON, never null
    total_amount || 0,           // Safe fallback
    restro_id
  ];

  try {
    const result = await db.query(query, values);
    return result.rows[0];
  } catch (error) {
    console.error('❌ Error creating order:', error);
    throw error;
  }
}

/**
 * Retrieves all orders for a specific restaurant.
 */
async function getAllOrders(restroId) {
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE restro_id = $1
    ORDER BY created_at DESC
  `;
  const result = await db.query(query, [restroId]);
  return result.rows;
}

/**
 * Retrieves a single order by ID for a specific restaurant.
 */
async function getOrderById(id, restroId) {
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE id = $1 AND restro_id = $2
  `;
  const result = await db.query(query, [id, restroId]);
  return result.rows[0];
}

/**
 * Retrieves an order by Table ID for a specific restaurant.
 */
async function getOrderByTableId(table_id, restroId) {
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE table_id = $1 AND restro_id = $2
    ORDER BY created_at DESC
  `;
  const result = await db.query(query, [table_id, restroId]);
  return result.rows[0];
}


async function getOrderHistory(restroId, filters) {
  let { from, to, month, year } = filters;

  let query = `
    SELECT id, table_id, total_amount, created_at
    FROM orders
    WHERE restro_id = $1
  `;

  let params = [restroId];
  let index = 2;  // next placeholder

  if (from && to) {
    query += ` AND created_at BETWEEN $${index} AND $${index + 1}`;
    params.push(from, to);
    index += 2;
  }

  if (month && year) {
    query += ` AND EXTRACT(MONTH FROM created_at) = $${index}
               AND EXTRACT(YEAR FROM created_at) = $${index + 1}`;
    params.push(month, year);
    index += 2;
  }

  query += ` ORDER BY created_at DESC`;

  const result = await db.query(query, params);
  return result.rows;
}


module.exports = {
  createOrder,
  getAllOrders,
  getOrderById,
  getOrderByTableId,
  getOrderHistory
};
