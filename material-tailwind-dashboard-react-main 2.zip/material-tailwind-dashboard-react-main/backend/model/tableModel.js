const db = require('../db/connect'); // Import the database connection and query function

// Table Model: { name: string, size: number, floor: string, restro_id: string }
// NOTE: Assuming the database table is named "table" and PostgreSQL quotes are used.
const TABLE_NAME = '"table"';


/**
 * Creates a new table, linking it to a specific restaurant.
 * @param {object} tableData - Table details.
 * @param {string} tableData.restro_id - The ID of the restaurant.
 */
async function createTable(tableData) {
    const query = `
        INSERT INTO ${TABLE_NAME} (name, size, floor, status, restro_id)
        VALUES ($1, $2, $3, true, $4)
        RETURNING *;
    `;
    // Assumes status is true (available) upon creation.
    const values = [tableData.name, tableData.size, tableData.floor, tableData.restro_id];

    try {
        const result = await db.query(query, values);
        return result.rows[0];
    } catch (error) {
        console.error('Error creating table:', error);
        throw error;
    }
}

/**
 * Retrieves a single table by its unique ID and restaurant ID.
 * Renamed to getTableById to avoid confusion with Primary Key (name).
 * @param {number} id - The unique ID of the table (Primary Key).
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<object|null>} The table data or null if not found or unauthorized.
 */
async function getTableById(id, restroId) {
    // Corrected table name and added restro_id filter
    const query = `
        SELECT * FROM ${TABLE_NAME}
        WHERE id = $1 AND restro_id = $2;
    `;

    try {
        const result = await db.query(query, [id, restroId]);
        return result.rows[0] || null;
    } catch (error) {
        console.error('Error getting table by ID:', error);
        throw error;
    }
}

/**
 * Retrieves all table records for a specific restaurant.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<Array<object>>} An array of table data objects.
 */
async function getAllTables(restroId) {
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE restro_id = $1
    ORDER BY floor, name;
  `;
  const result = await db.query(query, [restroId]);
  return result.rows;
}

/**
 * Updates an existing table record by its ID and restaurant ID.
 * @param {number} id - The unique ID of the table to update.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @param {{size?: number, floor?: string}} updates - The fields to update.
 * @returns {Promise<object|null>} The updated row data or null if the table was not found.
 */
async function updateTable(id, restroId, updates) {
    const setParts = [];
    const values = [];
    let paramIndex = 1;

    // Dynamically build the SET clause
    if (updates.name !== undefined) {
        setParts.push(`name = $${paramIndex++}`);
        values.push(updates.name);
    }
    if (updates.size !== undefined) {
        setParts.push(`size = $${paramIndex++}`);
        values.push(updates.size);
    }
    if (updates.floor !== undefined) {
        setParts.push(`floor = $${paramIndex++}`);
        values.push(updates.floor);
    }

    if (setParts.length === 0) {
        return getTableById(id, restroId); // Nothing to update
    }

    // Add ID and Restro ID to the end of the values array for the WHERE clause
    values.push(id);
    values.push(restroId);

    const idParam = paramIndex++;
    const restroParam = paramIndex;

    const query = `
        UPDATE ${TABLE_NAME}
        SET ${setParts.join(', ')}, updated_at = NOW()
        WHERE id = $${idParam} AND restro_id = $${restroParam}
        RETURNING *;
    `;

    try {
        const result = await db.query(query, values);
        return result.rows[0] || null;
    } catch (error) {
        console.error('Error updating table:', error);
        throw error;
    }
}

/**
 * Deletes a table record by its ID and restaurant ID.
 * @param {number} id - The ID of the table to delete.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<number>} The number of rows deleted (0 or 1).
 */
async function deleteTable(id, restroId) {
    const query = `
        DELETE FROM ${TABLE_NAME}
        WHERE id = $1 AND restro_id = $2;
    `;

    try {
        const result = await db.query(query, [id, restroId]);
        return result.rowCount; // Returns 1 if deleted, 0 if not found
    } catch (error) {
        console.error('Error deleting table:', error);
        throw error;
    }
}

/**
 * Marks a table as available (status = true) by ID and restro ID.
 */
async function closeTable(id, restroId){
    const query = `
        UPDATE ${TABLE_NAME}
        SET status = true
        WHERE id = $1 AND restro_id = $2
        RETURNING *;
    `;
    try {
         const result = await db.query(query, [id, restroId]);
         return result.rows[0] || null;
     } catch (error) {
         console.error('Error closing table (setting status=true):', error);
         throw error;
     }
}

/**
 * Marks a table as occupied (status = false) by ID and restro ID.
 */
async function markTableOccupied(id, restroId) {
  const query = `
    UPDATE ${TABLE_NAME}
    SET status = false
    WHERE id = $1 AND restro_id = $2
    RETURNING *;
  `;
  try {
    const result = await db.query(query, [id, restroId]);
    return result.rows[0] || null;
  } catch (error) {
    console.error('Error updating table status (setting status=false):', error);
    throw error;
  }
}



// Export all model functions (renamed markFalseTable to markTableOccupied for clarity)
module.exports = {
    createTable,
    getTableById,
    getAllTables,
    updateTable,
    deleteTable,
    markTableOccupied,
    closeTable
};
