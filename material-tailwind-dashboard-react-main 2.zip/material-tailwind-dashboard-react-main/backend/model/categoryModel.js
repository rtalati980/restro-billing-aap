const db = require('../db/connect');
const TABLE_NAME = '"category"';

/**
 * Creates a new category, linking it to a specific restaurant.
 * @param {object} data - Category details.
 * @param {string} data.name - The name of the category.
 * @param {string} data.restro_id - The ID of the restaurant (Tenant ID).
 * @returns {Promise<object>} The created category.
 */
async function createCategory({ name, restro_id }) {
  const query = `
    INSERT INTO ${TABLE_NAME} (name, restro_id)
    VALUES ($1, $2)
    RETURNING *;
  `;
  // ⭐ Added restro_id to the values array
  const result = await db.query(query, [name, restro_id]);
  return result.rows[0];
}

/**
 * Retrieves all categories for a specific restaurant.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<Array<object>>} An array of categories.
 */
async function getAllCategories(restroId) {
  // ⭐ Added WHERE clause to filter by restro_id
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE restro_id = $1
    ORDER BY id;
  `;
  const result = await db.query(query, [restroId]);
  return result.rows;
}

/**
 * Retrieves a single category by ID for a specific restaurant.
 * @param {number} id - The unique ID of the category.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<object|null>} The category data or null if not found.
 */
async function getCategoryById(id, restroId) {
  // ⭐ Added AND clause to enforce multi-tenancy
  const query = `
    SELECT * FROM ${TABLE_NAME}
    WHERE id = $1 AND restro_id = $2;
  `;
  const result = await db.query(query, [id, restroId]);
  return result.rows[0] || null;
}

/**
 * Updates a category for a specific restaurant.
 * Note: Only 'name' is being updated based on the original structure.
 * @param {number} id - The unique ID of the category.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @param {object} updates - The fields to update.
 * @returns {Promise<object|null>} The updated category or null if not found.
 */
async function updateCategory(id, restroId, { name }) {
  // Fixed SQL syntax (added comma) and enforced tenancy in WHERE clause
  const query = `
    UPDATE ${TABLE_NAME}
    SET name = COALESCE($1, name),
        updated_at = NOW()
    WHERE id = $2 AND restro_id = $3
    RETURNING *;
  `;
  // ⭐ Added restroId as the final parameter
  const result = await db.query(query, [name, id, restroId]);
  return result.rows[0] || null;
}

/**
 * Deletes a category for a specific restaurant.
 * @param {number} id - The unique ID of the category.
 * @param {string} restroId - The ID of the restaurant (Tenant ID).
 * @returns {Promise<number>} The number of rows deleted.
 */
async function deleteCategory(id, restroId) {
  // ⭐ Added tenancy filter to the DELETE operation
  const query = `
    DELETE FROM ${TABLE_NAME}
    WHERE id = $1 AND restro_id = $2;
  `;
  const result = await db.query(query, [id, restroId]);
  return result.rowCount;
}

module.exports = {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
  deleteCategory
};
