const express = require('express');
const { signInEmail, requestOtp, verifyOtp, signOut,signUpEmail ,signUpMobile} = require('../controller/authController');

const router = express.Router();

router.post('/signup/email', signUpEmail);
router.post('/signup/mobile', signUpMobile);
router.post('/signin/email', signInEmail);
router.post('/signin/mobile/request-otp', requestOtp);
router.post('/signin/mobile/verify-otp', verifyOtp);
router.post('/signout', signOut);


module.exports = router;