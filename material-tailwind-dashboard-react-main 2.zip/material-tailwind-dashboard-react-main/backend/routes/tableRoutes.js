const express = require('express');
const router = express.Router();
const tableController = require('../controller/tableController');
const { verifyToken } = require('../middleware/authMiddleware'); // Import middleware


router.post('/', verifyToken, tableController.createTable);          // Create
router.get('/', verifyToken, tableController.getAllTables);          // Get all
router.get('/:name', verifyToken, tableController.getTableById);     // Get by name
router.put('/:name', verifyToken, tableController.updateTable);      // Update
router.delete('/:name', verifyToken, tableController.deleteTable); // Delete
router.put('/:id/status', verifyToken, tableController.markTableOccupied); // Mark occupied


module.exports = router;
