const express = require('express');
const router = express.Router();
const categoryController = require('../controller/categoryController');
const { verifyToken } = require('../middleware/authMiddleware'); // Import middleware for protection

// ⭐ Applied 'protect' middleware to all category routes for login enforcement and tenancy
router.post('/', verifyToken, categoryController.createCategory);
router.get('/', verifyToken, categoryController.getAllCategories);
router.get('/:id', verifyToken, categoryController.getCategoryById);
router.put('/:id', verifyToken, categoryController.updateCategory);
router.delete('/:id', verifyToken, categoryController.deleteCategory);

module.exports = router;
