const express = require('express');
const router = express.Router();
const orderController = require('../controller/orderController');
const { verifyToken } = require('../middleware/authMiddleware'); // Import middleware for verifyTokenion

router.post("/", verifyToken, orderController.createOrder);
router.get("/", verifyToken, orderController.getAllOrders);

router.get("/history", verifyToken, orderController.getHistory);

router.get("/:id/bill", verifyToken, orderController.generateBill);
router.put("/:id/close", verifyToken, orderController.closeTable);
router.get("/:id/table", verifyToken, orderController.getOrderByTableId);

router.get("/:id", verifyToken, orderController.getOrderById);


module.exports = router;
