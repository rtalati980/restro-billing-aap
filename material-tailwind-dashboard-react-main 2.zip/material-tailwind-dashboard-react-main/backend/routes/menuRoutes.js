const express = require('express');
const router = express.Router();
const menuController = require('../controller/menuController');
const { verifyToken } = require('../middleware/authMiddleware'); // Import middleware for verifyTokenion

// ⭐ Applied 'verifyToken' middleware to all menu routes for login enforcement and tenancy
router.post('/', verifyToken, menuController.createMenuItem);
router.get('/', verifyToken, menuController.getAllMenuItems);
router.get('/category/:category_id', verifyToken, menuController.getMenuByCategory);
router.put('/:id', verifyToken, menuController.updateMenuItem);
router.delete('/:id', verifyToken, menuController.deleteMenuItem);

module.exports = router;
