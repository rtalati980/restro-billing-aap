const menuModel = require('../model/menuModel');

// Helper function to extract restroId and validate
const getRestroId = (req, res) => {
    // This assumes authMiddleware has run and attached restroId from the JWT
    const restroId = req.restroId;
    if (!restroId) {
        // This should theoretically not happen if the route is protected
        console.error('Missing restroId in protected route.');
        res.status(403).json({ error: 'Tenant ID required' });
        return null;
    }
    return restroId;
};

exports.createMenuItem = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Inject the restro_id into the creation data
        const menuData = { ...req.body, restro_id: restroId };

        const menu = await menuModel.createMenuItem(menuData);
        res.status(201).json(menu);

    } catch (err) {
        console.error('Error creating menu item:', err);
        res.status(500).json({ error: 'Failed to create menu item' });
    }
};

exports.getAllMenuItems = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to filter menu items
        const items = await menuModel.getAllMenuItems(restroId);
        res.json(items);
    } catch (err) {
        console.error('Error fetching menu items:', err);
        res.status(500).json({ error: 'Failed to fetch menu items' });
    }
};

exports.getMenuByCategory = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { category_id } = req.params;
        // ⭐ Pass restroId along with category_id
        const items = await menuModel.getMenuByCategory(category_id, restroId);
        res.json(items);
    } catch (err) {
        console.error('Error fetching menu by category:', err);
        res.status(500).json({ error: 'Failed to fetch menu by category' });
    }
};

exports.updateMenuItem = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass id, restroId, and body to the model
        const updated = await menuModel.updateMenuItem(id, restroId, req.body);

        if (!updated) return res.status(404).json({ message: 'Menu item not found or does not belong to your restaurant' });
        res.json(updated);
    } catch (err) {
        console.error('Error updating menu item:', err);
        res.status(500).json({ error: 'Failed to update menu item' });
    }
};

exports.deleteMenuItem = async (req, res) => {

console.log("gwha");
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass id and restroId to the model
        const deleted = await menuModel.deleteMenuItem(id, restroId);

        if (deleted === 0) return res.status(404).json({ message: 'Menu item not found or does not belong to your restaurant' });
        res.json({ message: 'Menu item deleted successfully' });
    } catch (err) {
        console.error('Error deleting menu item:', err);
        res.status(500).json({ error: 'Failed to delete menu item' });
    }
};
