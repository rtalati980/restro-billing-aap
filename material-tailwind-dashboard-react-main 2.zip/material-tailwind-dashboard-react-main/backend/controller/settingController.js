const Settings = require("../model/settingModel");


const getRestroId = (req, res) => {
    // This assumes authMiddleware has run and attached restroId from the JWT
    const restroId = req.restroId;
    if (!restroId) {
        // This should theoretically not happen if the route is protected
        console.error('Missing restroId in protected route.');
        res.status(403).json({ error: 'Tenant ID required' });
        return null;
    }
    return restroId;
};

exports.getSettings = async (req, res) => {
  const restroId = getRestroId(req, res);
  if (!restroId) return;

  const settings = await Settings.getSettings(restroId);
  res.json(settings);
};

exports.updateSettings = async (req, res) => {
  const restroId = getRestroId(req, res);
  if (!restroId) return;

  const updated = await Settings.updateSettings(restroId, req.body);
  res.json({ message: "Settings Updated", updated });
};
