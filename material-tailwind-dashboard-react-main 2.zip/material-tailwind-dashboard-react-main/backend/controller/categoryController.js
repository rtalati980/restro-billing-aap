const categoryModel = require('../model/categoryModel'); // Using plural 'models' for standard practice

// Helper function to extract restroId and validate
const getRestroId = (req, res) => {
    // This assumes authMiddleware has run and attached restroId from the JWT
    const restroId = req.restroId;
    if (!restroId) {
        // This should theoretically not happen if the route is protected
        console.error('Missing restroId in protected route.');
        res.status(403).json({ error: 'Tenant ID required' });
        return null;
    }
    return restroId;
};

exports.createCategory = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Inject the restro_id into the creation data
        const categoryData = { ...req.body, restro_id: restroId };
        const category = await categoryModel.createCategory(categoryData);
        res.status(201).json(category);
    } catch (err) {
        console.error('Error creating category:', err);
        res.status(500).json({ error: 'Failed to create category' });
    }
};

exports.getAllCategories = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to the model to filter categories
        const categories = await categoryModel.getAllCategories(restroId);
        res.json(categories);
    } catch (err) {
        console.error('Error fetching categories:', err);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
};

exports.getCategoryById = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass restroId to enforce tenancy lookup
        const category = await categoryModel.getCategoryById(id, restroId);

        if (!category) return res.status(404).json({ message: 'Category not found or does not belong to your restaurant' });
        res.json(category);
    } catch (err) {
        console.error('Error fetching category:', err);
        res.status(500).json({ error: 'Failed to fetch category' });
    }
};

exports.updateCategory = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass id, restroId, and body to the model
        const updated = await categoryModel.updateCategory(id, restroId, req.body);

        if (!updated) return res.status(404).json({ message: 'Category not found or does not belong to your restaurant' });
        res.json(updated);
    } catch (err) {
        console.error('Error updating category:', err);
        res.status(500).json({ error: 'Failed to update category' });
    }
};

exports.deleteCategory = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass id and restroId to the model
        const deleted = await categoryModel.deleteCategory(id, restroId);

        if (deleted === 0) return res.status(404).json({ message: 'Category not found or does not belong to your restaurant' });
        res.json({ message: 'Category deleted successfully' });
    } catch (err) {
        console.error('Error deleting category:', err);
        res.status(500).json({ error: 'Failed to delete category' });
    }
};
