const orderModel = require('../model/orderModel');
const tableModel = require('../model/tableModel');
const PDFDocument = require("pdfkit");
const fs = require("fs");
const db = require('../db/connect');
const path = require("path");

// Helper function to extract restroId and validate
const getRestroId = (req, res) => {
    // This assumes authMiddleware has run and attached restroId from the JWT
    const restroId = req.restroId;
    if (!restroId) {
        // This should theoretically not happen if the route is protected
        console.error('Missing restroId in protected route.');
        res.status(403).json({ error: 'Tenant ID required' });
        return null;
    }
    return restroId;
};

exports.createOrder = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Fetch restaurant settings
        const settingsQuery = await db.query(
            `SELECT tax_percent, service_charge, packing_charge
             FROM settings WHERE restro_id = $1 LIMIT 1`,
            [restroId]
        );

        const settings = settingsQuery.rows[0] || {
            tax_percent: 0,
            service_charge: 0,
            packing_charge: 0
        };

        const items = req.body.items;
        if (!Array.isArray(items)) {
            return res.status(400).json({ error: "Invalid items" });
        }

        // ⭐ Calculate subtotal
        let subtotal = 0;
        items.forEach(item => {
            subtotal += Number(item.qty) * Number(item.price);
        });

        // ⭐ Calculate charges
        const gstAmount = +(subtotal * (settings.tax_percent / 100)).toFixed(2);
        const serviceCharge = +(subtotal * (settings.service_charge / 100)).toFixed(2);
        const packingCharge = Number(settings.packing_charge);
        const totalAmount = subtotal + gstAmount + serviceCharge + packingCharge;

        // ⭐ Inject Restro + Totals
        const orderData = {
            ...req.body,
            total_amount: totalAmount,
            restro_id: restroId
        };

        const order = await orderModel.createOrder(orderData);
        res.status(201).json(order);

    } catch (err) {
        console.error("Error creating order:", err);
        res.status(500).json({ error: "Failed to create order" });
    }
};


exports.getAllOrders = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to the model to filter orders
        const orders = await orderModel.getAllOrders(restroId);
        res.status(200).json(orders);
    } catch (err) {
        console.error('Error fetching orders:', err);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};

exports.getOrderById = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to the model
        const order = await orderModel.getOrderById(req.params.id, restroId);
        if (!order) return res.status(404).json({ error: 'Order not found or does not belong to your restaurant' });
        res.status(200).json(order);
    } catch (err) {
        console.error('Error fetching order:', err);
        res.status(500).json({ error: 'Failed to fetch order' });
    }
};

exports.getOrderByTableId = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to the model
        const order = await orderModel.getOrderByTableId(req.params.id, restroId);
        if (!order) return res.status(404).json({ error: 'Order not found for this table or does not belong to your restaurant' });
        res.status(200).json(order);
    } catch (err) {
        console.error('Error fetching order:', err);
        res.status(500).json({ error: 'Failed to fetch order' });
    }
};

exports.closeTable = async (req, res) => {
    const restroId = getRestroId(req, res);
    console.log(req);
    if (!restroId) return;

    try {
        const tableId = req.params.id;
        // ⭐ Pass restroId to the table model function
        const updatedTable = await tableModel.closeTable(tableId, restroId);

        if (!updatedTable) {
            return res.status(404).json({ error: 'Table not found, already closed, or does not belong to your restaurant' });
        }

        res.status(200).json({ message: 'Table closed successfully', table: updatedTable });
    } catch (err) {
        console.error('Error closing table:', err);
        res.status(500).json({ error: 'Failed to close table' });
    }
};

exports.generateBill = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    const { id } = req.params;

    try {
        // ⭐ Fetch Latest Order
        const orderQuery = await db.query(
            `SELECT id, created_at, items, total_amount
             FROM orders WHERE table_id = $1 AND restro_id = $2
             ORDER BY created_at DESC LIMIT 1`,
            [id, restroId]
        );

        const order = orderQuery.rows[0];
        if (!order) return res.status(404).json({ error: "Order not found" });

        // ⭐ Fetch Restaurant Settings
        const settingsQuery = await db.query(
            `SELECT restro_name, tax_percent, service_charge, packing_charge
             FROM settings WHERE restro_id=$1`,
            [restroId]
        );

        const settings = settingsQuery.rows[0] || {
            restro_name: "Restaurant",
            gst_number: "N/A"
        };

        const orderItems = order.items;
        if (!Array.isArray(orderItems)) {
            return res.status(500).json({ error: "Invalid items format" });
        }

        // ---------------------------------------
        // 🧾 PDF BILL GENERATION
        // ---------------------------------------
        const doc = new PDFDocument({ margin: 40 });
        const fileName = `bill_table_${id}.pdf`;
        const filePath = path.join(__dirname, "../bills", fileName);

        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        const writeStream = fs.createWriteStream(filePath);
        doc.pipe(writeStream);

        doc.fontSize(20).text(settings.restro_name, { align: "center" }).moveDown(0.2);
        doc.fontSize(10).text(`GSTIN: ${settings.gst_number}`, { align: "center" }).moveDown(0.5);
        doc.fontSize(14).text(`Bill for Table: ${id}`, { align: "center" }).moveDown(1);

        doc.fontSize(12).text(`Order ID: ${order.id}`);
        doc.text(`Date: ${new Date(order.created_at).toLocaleString()}`);
        doc.moveDown(1);

        // ITEM TABLE
        const startX = 60;
        const col1 = 60, col2 = 260, col3 = 320, col4 = 420;
        doc.fontSize(13)
            .text("Item", col1)
            .text("Qty", col2)
            .text("Price", col3)
            .text("Total", col4);

        doc.moveTo(startX, doc.y).lineTo(500, doc.y).stroke();

        orderItems.forEach(item => {
            const qty = Number(item.qty);
            const price = Number(item.price);
            const total = qty * price;

            doc.fontSize(12)
                .text(item.item_name, col1, doc.y + 5)
                .text(qty.toString(), col2, doc.y + 5)
                .text(price.toFixed(2), col3, doc.y + 5)
                .text(total.toFixed(2), col4, doc.y + 5);

            doc.moveDown(0.8);
        });

        doc.moveTo(startX, doc.y).lineTo(500, doc.y).stroke();

        doc.text(`Service Charge: ₹${settings.tax_percent}`, { align: "right" });
        doc.text(`Service Charge: ₹${settings.service_charge}`, { align: "right" });
        doc.text(`Packing Charge: ₹${settings.packing_charge}`, { align: "right" });
        doc.fontSize(14).text(`TOTAL: ₹${order.total_amount}`, { align: "right" });

        doc.moveDown(2).fontSize(10).text("Thank You! Visit again ❤️", { align: "center" });

        doc.end();

        writeStream.on("finish", () => {
            res.download(filePath, fileName);
        });

    } catch (err) {
        console.error("Bill generation error:", err);
        res.status(500).json({ error: "Failed to generate bill" });
    }
};

exports.getHistory = async (req, res) => {
  const restroId = getRestroId(req, res);
  if (!restroId) return;

  try {
    const orders = await orderModel.getOrderHistory(restroId, req.query);
    res.json({ orders });
  } catch (err) {
    console.error("Order history error:", err);
    res.status(500).json({ error: "Server Error" });
  }
};






