const database = require('../db/connect');// Your database connection file
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// NOTE: otpGenerator is assumed to be imported or required elsewhere.
// Adding a simple mock here for reference based on your original code's usage.
const otpGenerator = {
  generate: () => Math.floor(100000 + Math.random() * 900000).toString(),
};


// 1. Updated to include restro_id in the token payload
function createToken(user) {
    return jwt.sign(
        {
            userId: user.id,         // key name must match what verifyToken reads
            restroId: user.restro_id // key name must match what verifyToken reads
        },
        process.env.JWT_SECRET || 'secret', // use env secret
        { expiresIn: '7d' }
    );
}


// --- 1. EMAIL/PASSWORD SIGN IN ---
exports.signInEmail = async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await database.query(
            'SELECT id, password, restro_id FROM users WHERE email = $1',
            [email]
        );

        const user = result.rows[0];

        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        // Compare hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials.' });
        }

        // Generate JWT token
        const token = createToken(user);

        // Respond with token and user info
        res.status(200).json({
            token,
            userId: user.id,
            restroId: user.restro_id,
            method: 'email'
        });
    } catch (err) {
        console.error('Email Sign In Error:', err);
        res.status(500).json({ message: 'Server error during sign in.' });
    }
};



// --- 2. MOBILE/OTP - REQUEST OTP ---
exports.requestOtp = async (req, res) => {
    // NOTE: For multi-tenancy, if registration is allowed here (in the 'else' block),
    // the endpoint would need to be updated to accept `restro_id`.
    const { mobile } = req.body;
    const otpCode = otpGenerator.generate(6, { digits: true, upperCaseAlphabets: false, specialChars: false, lowerCaseAlphabets: false });
    // PostgreSQL timestamp function for 5 minutes later
    const otpExpires = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    try {
        // We select the ID and ensure the user exists before sending OTP
        const result = await database.query('SELECT id, restro_id FROM users WHERE mobile = $1', [mobile]);
        const userExists = result.rows.length > 0;

        if (userExists) {
            // Update existing user's OTP
            await database.query(
                'UPDATE users SET otp = $1, otp_expires = $2 WHERE mobile = $3',
                [otpCode, otpExpires, mobile]
            );
        } else {
             // ⚠️ If new user registration is needed here, restro_id must be provided to the endpoint.
             // Assuming explicit sign-up is used (5 or 6) for new multi-tenant users.
             return res.status(404).json({ message: 'User not registered. Please sign up first.' });
        }

        // --- PRODUCTION STEP: Send SMS via Twilio/Fast2SMS ---
        // (Twilio code remains the same as previous answer)
        // --- END PRODUCTION STEP ---

        console.log(`OTP for ${mobile}: ${otpCode}`);
        res.status(200).json({ message: 'OTP sent successfully. Check console/SMS.' });

    } catch (err) {
        console.error('Request OTP Error:', err);
        res.status(500).json({ message: 'Error sending OTP.', error: err.message });
    }
};

// --- 3. MOBILE/OTP - VERIFY OTP & SIGN IN ---
exports.verifyOtp = async (req, res) => {
    const { mobile, otp } = req.body;

    try {
        // ⭐ Select restro_id
        const result = await database.query(
            'SELECT id, restro_id FROM users WHERE mobile = $1 AND otp = $2 AND otp_expires > NOW()',
            [mobile, otp]
        );
        const user = result.rows[0];

        if (!user) {
            return res.status(401).json({ message: 'Invalid or expired OTP.' });
        }

        // OTP is valid, clear OTP fields and mark as verified
        await database.query(
            'UPDATE users SET otp = NULL, otp_expires = NULL, is_verified = TRUE WHERE id = $1',
            [user.id]
        );

        // ⭐ Pass user object to createToken
        const token = createToken(user);
        res.status(200).json({ token, userId: user.id, restroId: user.restro_id, method: 'mobile' });

    } catch (err) {
        console.error('Verify OTP Error:', err);
        res.status(500).json({ message: 'Server error during OTP verification.' });
    }
};

// --- 4. SIGN OUT ---
exports.signOut = (req, res) => {
    // With JWT, sign out is client-side.
    res.status(200).json({ message: 'Sign out successful (Token removed client-side).' });
};


// --- 5. EMAIL/PASSWORD SIGN UP ---
exports.signUpEmail = async (req, res) => {
    // ⭐ Added restro_id to required fields
    const { name, email, password, restro_id } = req.body;



    // ⭐ Check for restro_id
    if (!name || !email || !password || !restro_id) {
        return res.status(400).json({ message: 'All fields (name, email, password, restro_id) are required.' });
    }

   try {
       await database.query("BEGIN");  // Start Transaction

       // 1️⃣ Insert User
       await database.query(
           `INSERT INTO users (name, email, password, restro_id, is_verified)
            VALUES ($1, $2, $3, $4, TRUE)`,
           [name, email, hashedPassword, generateRestroId]
       );

       // 2️⃣ Insert DEFAULT Settings Row
       await database.query(
           `INSERT INTO settings (
               restro_id
           )
           VALUES ($1)`,
           [generateRestroId]
       );

       await database.query("COMMIT"); // Commit
       res.status(201).json({ message: "User + Settings Created Successfully" });

   } catch (err) {
       await database.query("ROLLBACK");
       console.error("SIGNUP ERROR:", err);
       return res.status(500).json({ message: "Failed to register user" });
   }

};

// --- 6. MOBILE SIGN UP (Registers user, verification happens on first sign in) ---
exports.signUpMobile = async (req, res) => {
    // ⭐ Added restro_id to required fields
    const { name, mobile, restro_id } = req.body;

    // ⭐ Check for restro_id
    if (!name || !mobile || !restro_id) {
        return res.status(400).json({ message: 'Name, mobile, and restro_id are required.' });
    }

    try {
        // 1. Check if mobile already exists
        const checkResult = await database.query('SELECT id FROM users WHERE mobile = $1', [mobile]);
        if (checkResult.rows.length > 0) {
            return res.status(409).json({ message: 'Mobile number already in use.' });
        }

        // 2. Insert new user into the database, including restro_id
        await database.query(
            // ⭐ Added restro_id to the columns and values list
            'INSERT INTO users (name, mobile, restro_id, is_verified) VALUES ($1, $2, $3, FALSE)',
            [name, mobile, restro_id]
        );
          await database.query(
                    `INSERT INTO settings (
                        restro_id
                    )
                    VALUES ($1)`,
                    [generateRestroId]
                );


        res.status(201).json({ message: 'User registered successfully with mobile number.' });

    } catch (err) {
        console.error('Mobile Sign Up Error:', err);
        res.status(500).json({ message: 'Server error during mobile sign up.' });
    }
};