const tableModel = require('../model/tableModel'); // Note: Updated path to plural 'models' for standard practice

// Helper function to extract restroId and validate
const getRestroId = (req, res) => {
    // This assumes authMiddleware has run and attached restroId from the JWT
    const restroId = req.restroId;
    if (!restroId) {
        // This should theoretically not happen if the route is protected
        console.error('Missing restroId in protected route.');
        res.status(403).json({ error: 'Tenant ID required' });
        return null;
    }
    return restroId;
};

// Create a new table
exports.createTable = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Inject the restroId into the table creation data
        const tableData = { ...req.body, restro_id: restroId };
        const newTable = await tableModel.createTable(tableData);
        res.status(201).json(newTable);
    } catch (error) {
        console.error('Error creating table:', error);
        res.status(500).json({ error: 'Failed to create table' });
    }
};

// Get all tables for the restaurant
exports.getAllTables = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        // ⭐ Pass restroId to the model to filter results
        const tables = await tableModel.getAllTables(restroId);
        res.status(200).json(tables);
    } catch (error) {
        console.error('Error fetching tables:', error);
        res.status(500).json({ error: 'Failed to fetch tables' });
    }
};

// Get table by name (ID) for the restaurant
exports.getTableById = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { name } = req.params;
        // ⭐ Pass restroId to the model to enforce tenancy
        const table = await tableModel.getTableById(name, restroId);
        if (!table) return res.status(404).json({ message: 'Table not found or does not belong to your restaurant' });
        res.status(200).json(table);
    } catch (error) {
        console.error('Error fetching table:', error);
        res.status(500).json({ error: 'Failed to fetch table' });
    }
};

// Update a table for the restaurant
exports.updateTable = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { name } = req.params;
        // ⭐ Pass restroId to the model for the WHERE clause
        const updatedTable = await tableModel.updateTable(name, restroId, req.body);
        if (!updatedTable) return res.status(404).json({ message: 'Table not found or does not belong to your restaurant' });
        res.status(200).json(updatedTable);
    } catch (error) {
        console.error('Error updating table:', error);
        res.status(500).json({ error: 'Failed to update table' });
    }
};

// Delete a table for the restaurant
exports.deleteTable = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { name } = req.params;
        // ⭐ Pass restroId to the model for the DELETE operation
        const deleted = await tableModel.deleteTable(name, restroId);
        if (deleted === 0) return res.status(404).json({ message: 'Table not found or does not belong to your restaurant' });
        res.status(200).json({ message: 'Table deleted successfully' });
    } catch (error) {
        console.error('Error deleting table:', error);
        res.status(500).json({ error: 'Failed to delete table' });
    }
};

// Mark a table as occupied (status = false) for the restaurant
exports.markTableOccupied = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Pass restroId to the model
        const updatedTable = await tableModel.markTableOccupied(id, restroId);

        if (!updatedTable) {
            return res.status(404).json({ error: 'Table not found or does not belong to your restaurant' });
        }

        res.status(200).json({
            message: 'Table marked as occupied (status = false)',
            table: updatedTable,
        });
    } catch (error) {
        console.error('Error marking table occupied:', error);
        res.status(500).json({ error: 'Failed to update table status' });
    }
};

// Assuming you also need a way to mark it available
exports.markTableAvailable = async (req, res) => {
    const restroId = getRestroId(req, res);
    if (!restroId) return;

    try {
        const { id } = req.params;
        // ⭐ Assuming the model has a function to mark a table available (status = true)
        const updatedTable = await tableModel.markTableAvailable(id, restroId);

        if (!updatedTable) {
            return res.status(404).json({ error: 'Table not found or does not belong to your restaurant' });
        }

        res.status(200).json({
            message: 'Table marked as available (status = true)',
            table: updatedTable,
        });
    } catch (error) {
        console.error('Error marking table available:', error);
        res.status(500).json({ error: 'Failed to update table status' });
    }
};
