const express = require('express');
const cors = require('cors');
const db = require('./db/connect');
const tableRoutes = require('./routes/tableRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const menuRoutes = require('./routes/menuRoutes');
const orderRoutes = require('./routes/orderRoutes');
const authRoutes = require('./routes/authRoutes');
const settingsRoutes = require("./routes/settingRoutes");// ✅ Import your router

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // ✅ Needed to parse JSON request bodies

// API Routes
app.use('/api/tables', tableRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/menus', menuRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/auth', authRoutes);
app.use("/api/settings", settingsRoutes);


// Test Route
app.get('/', (req, res) => {
  res.send('✅ Restaurant Table Management API is running...');
});

// Database Connection
db.connect((err) => {
  if (err) {
    console.error('❌ Database connection failed:', err.stack);
    return;
  }
  console.log('✅ Connected to database.');
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
