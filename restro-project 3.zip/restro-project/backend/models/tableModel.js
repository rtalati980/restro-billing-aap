const pool = require('../config/db');

// Model function to insert table
const createTable = async ({ name, size, floor }) => {
  const query = 'INSERT INTO "table" (name, size, floor) VALUES ($1, $2, $3) RETURNING *';
  const values = [name, size, floor];

  const result = await pool.query(query, values);
  return result.rows[0]; // return the inserted row
};

const findById = async ({ id }) => {
  const query = 'SELECT * FROM "table" WHERE id = $1';
  const values = [id];

  const result = await pool.query(query, values);
  return result.rows[0]; // return single record if exists
};


module.exports = { createTable,findById };
