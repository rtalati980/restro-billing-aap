const { Pool } = require('pg');


const pool = new Pool({
  host: 'localhost',
  user: 'postgres',
  port: 5432,
  password: 'root',
  database: 'restro-project'
});

pool.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to database.');
});

module.exports = pool;