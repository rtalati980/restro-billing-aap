const express = require('express');
const router = express.Router();
const tableController = require('../controller/tableController');

router.post('/create', tableController.create);
router.get('/byId/:id',tableController.getTableByIdController);

module.exports = router;
