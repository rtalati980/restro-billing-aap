const { createTable , findById } = require('../models/tableModel');

const create = async (req, res) => {
  try {
    const tableData = req.body;

    console.log(req.body);// { name, size, floor }
    const newTable = await createTable(tableData);

    res.status(201).json({
      message: 'Table created successfully',
      table: newTable
    });
  } catch (err) {
    console.error('Error creating table:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const getTableByIdController = async (req, res) => {
  try {
    const { id } = req.params;

    const table = await findById({ id });

    if (!table) {
      return res.status(404).json({ error: 'Table not found' });
    }

    return res.status(200).json(table);
  } catch (error) {
    console.error('Error fetching table:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};



module.exports = { create ,getTableByIdController };
