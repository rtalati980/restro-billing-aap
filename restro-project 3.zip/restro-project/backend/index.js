const express = require('express');
const pool = require('./config/db');
const tableRoutes = require('./routes/tableRoutes');

const app = express(); // create Express app
const hostname = '127.0.0.1';
const port = 3000;

// Middleware to parse JSON
app.use(express.json());

// Mount routes
app.use('/api/tables', tableRoutes);

// Test database connection
pool.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Start server
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});
